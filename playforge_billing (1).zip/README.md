// Contenido simulado para README.md
