// Contenido simulado para admin/index.php
