// Contenido simulado para admin/announcements.php
