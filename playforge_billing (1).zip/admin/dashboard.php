// Contenido simulado para admin/dashboard.php
