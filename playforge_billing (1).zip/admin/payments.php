// Contenido simulado para admin/payments.php
