// Contenido simulado para includes/db.php
