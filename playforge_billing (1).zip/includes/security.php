// Contenido simulado para includes/security.php
