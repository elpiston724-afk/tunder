// Contenido simulado para api/index.js
