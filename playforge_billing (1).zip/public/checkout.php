// Contenido simulado para public/checkout.php
