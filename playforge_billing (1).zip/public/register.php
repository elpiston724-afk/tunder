// Contenido simulado para public/register.php
