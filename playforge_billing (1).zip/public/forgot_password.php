// Contenido simulado para public/forgot_password.php
