// Contenido simulado para public/dashboard.php
