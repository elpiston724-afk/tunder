// Contenido simulado para public/index.php
