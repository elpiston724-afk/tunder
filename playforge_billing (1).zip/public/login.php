// Contenido simulado para public/login.php
