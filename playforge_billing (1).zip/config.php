// Contenido simulado para config.php
