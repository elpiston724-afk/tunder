// Contenido simulado para database.sql
